
<?php echo $__env->make('contact/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('contact/viewDatamodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="body-container">
    <?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="container-main">
    <div class="content">
        <div class="top-bar">
            <h1>Ligações</h1>
        </div>
        <div class="aux-bar">
            <h2>Ligacões</h2>
            <form class="search-contact" action="<?php echo e(route('searchCall')); ?>" method="GET">
                <input type="search" id="botao" class="form-control" name="search" placeholder="Pesquisar contato" />
            </form>
        </div>
        <div class="content-table">
            <table class="table-content">
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Ligação</th>
                    <th>Retorno</th>
                    <th>Ação</th>
                </tr>
                </thead>
            <tbody id="tabela">
              <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($dado->name); ?> </td>
                    <td> <?php echo e($dado->phone); ?> </td>
                    <td> <?php echo e(date('d-m-Y',strtotime($dado->date_contact))); ?> </td>
                    <td> <?php if($dado->scheduled_return != ''): ?> 
                                <?php echo e(date('d-m-Y',strtotime($dado->scheduled_return))); ?> 
                        <?php endif; ?> 
                    </td>
                    <td id='toview'>
                      <div class='dropdown'>
                        <img src='/img/tres-pontinhos.png' alt='três pontinhos' type='button' id='dropdownImage' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'/>
                        <div class='dropdown-menu' aria-labelledby='dropdownImage'>
                          <a href="#" class='dropdown-item btnToView' id="<?php echo e($dado->id); ?>">Visualizar</a>
                          <a href="<?php echo e(route('destroy',$dado->id)); ?>" class='dropdown-item btnDelete'>Excluir</a>
                        </div>
                      </div>
                    </td>
                    </tr>
                    <tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
        </table>
      </div>
    </div>
    <div class="content">
      <ul class="pagination"> </ul>
    </div>
  </section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('/js/contact.js')); ?>"></script>
</body>  
</html>
<script src="<?php echo e(asset('js/function.js')); ?>"></script> 


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\censupeg\resources\views//call/call.blade.php ENDPATH**/ ?>