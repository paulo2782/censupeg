<footer class="footer">
	<div class="copyright">
	    © <?php echo e(date('Y')); ?> - Todos os Direitos Reservados
	</div>
</footer>  
</div>
 <?php /**PATH C:\censupeg\resources\views/includes/footer.blade.php ENDPATH**/ ?>