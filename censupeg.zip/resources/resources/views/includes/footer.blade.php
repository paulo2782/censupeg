<footer class="footer">
	<div class="copyright">
	    © {{ date('Y') }} - Todos os Direitos Reservados
	</div>
</footer>  
</div>
 