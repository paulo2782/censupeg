@extends('layouts.app')
<body class="body-container">
  @include('includes/header')
</body>