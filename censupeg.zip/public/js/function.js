if($('#message').is(':visible')){
   

    $('#message').fadeOut(8000)
}
