
<form method="POST" action="<?php echo e(route('login')); ?>">
<?php echo csrf_field(); ?>

<div id="login">
    <div class="container">
        <img class="login-img my-4" src="img/logo-censupeg.png" alt="Logo censupeg">
        <h1 class="my-2 text-center">Acesse sua conta </h1>
        <form name="frmLogin" id="frmLogin">
            <div class="form-group">
                <label for="username">Usuário:</label>
                <input type="email" name="email" id="email" placeholder="Informe seu email" class="form-control">
            </div>
            <div class="form-group">
                <label for="password" >Senha:</label>
                <input type="password" name="password" id="password" placeholder="Informe sua senha" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary form-control"> 
                <?php echo e(__('Login')); ?>

            </button>
            <div class="mt-4">
                <div class="d-flex justify-content-center">
                    Para se registrar? <a onclick="window.location.href='register'" class="ml-2 login-a">Clique aqui</a>
                </div>
                <div class="d-flex justify-content-center">

                </div>
            </div>                        
            <div id="message">
                <div class="text-center"> <?php $__errorArgs = ['messages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>  
        </form>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"
></script>
<script src="<?php echo e(asset('js/function.js')); ?>"></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\censupeg\resources\views/auth/login.blade.php ENDPATH**/ ?>