
<?php echo $__env->make('contact/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<body id="body-container">
  <?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="container-main">
    <div class="container">
        <div class="content">
            <div class="top-bar">
                <h1>Contatos</h1>
                <a href="#"><img src="<?php echo e(asset('img/button-add.png')); ?>" alt="Botão adicionar" id="btnAdd"></a>
            </div>
            <span id="message"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <p><b><?php echo e($error); ?></b></p> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
            <div class="aux-bar">
                <h2>Contatos </h2>
                <form class="search-contact" action="<?php echo e(route('searchContact')); ?>">
                    <input type="search" id="search" name="search" class="form-control" placeholder=" Pesquisar contato" />
                </form>
            </div>
            <div class="content-table">
                <span class="text-4"><?php echo e($dados->appends(['search'=>$search])->links()); ?></span>
                <table class="table-content">
                    <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Telefone</th>
                        <th>Operador</th>
                        <th>Ação</th>
                    </tr>
                    </thead>  
                    <tbody id="tabela">
                    <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><a href="<?php echo e(route('viewData',$dado->id)); ?>"> <?php echo e($dado->name); ?> </td> </a>
                        <td><a href="<?php echo e(route('viewData',$dado->id)); ?>"> <?php echo e($dado->email); ?> </td> </a>
                        <td><a href="<?php echo e(route('viewData',$dado->id)); ?>"> <?php echo e($dado->phone); ?> </td> </a>
                        <td><a href="<?php echo e(route('viewData',$dado->id)); ?>"> <?php echo e($dado->user->name); ?></td> </a>
                        <td id='toview'>
                            <div class='dropdown'>
                            <img src='/img/tres-pontinhos.png' alt='três pontinhos' type='button' id='dropdownImage' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'/>
                            <div class='dropdown-menu' aria-labelledby='dropdownImage'>
                                <a href="<?php echo e(route('viewData',$dado->id)); ?>" class='dropdown-item btnToView' id="<?php echo e($dado->id); ?>">Visualizar</a>
                                <a href="<?php echo e(route('destroy',$dado->id)); ?>" class='dropdown-item btnDelete'>Excluir</a>
                            </div>
                            </div>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="content">
            <ul class="pagination"> </ul>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('/js/contact.js')); ?>"></script>
</body>  
</html>
<script src="<?php echo e(asset('js/function.js')); ?>"></script> 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\censupeg\resources\views//contact/contact.blade.php ENDPATH**/ ?>