
<?php echo $__env->make('contact/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="body-container">
  <?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="container-main">
    <div class="container">
        <div class="content">
            <div class="top-bar">
                <h1>Ligações</h1>
            </div>
        <div class="aux-bar">
            <h2>Ligacões</h2>
            <form class="search-contact" action="<?php echo e(route('searchCall')); ?>" method="GET">
                <input type="search" id="botao" class="form-control" name="search" placeholder="Pesquisar contato" />
            </form>
        </div>
        <div class="content-table">
            <table class="table-content">
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Ligação</th>
                    <th>Retorno</th>
                    <th>Ação</th>
                </tr>
                </thead>
            <tbody id="tabela">
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <!-- foreach($data as $data) -->
                    <?php if($data > 0): ?>
                    <td id='toview'>
                      <div class='dropdown'>
                        <img src='/img/tres-pontinhos.png' alt='três pontinhos' type='button' id='dropdownImage' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'/>
                        <div class='dropdown-menu' aria-labelledby='dropdownImage'>
                          <a href="#" class='dropdown-item btnToView' id="#">Visualizar</a>
                          <a href="#" class='dropdown-item btnDelete'>Excluir</a>
                        </div>
                      </div>
                    </td>
                    <?php endif; ?>
                    <!-- endforeach -->
                </tr>                    
            </tbody>
        </table>
      </div>
    </div>
    <div class="content">
      <ul class="pagination"> </ul>
    </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('/js/contact.js')); ?>"></script>
</body>  
</html>
<script src="<?php echo e(asset('js/function.js')); ?>"></script> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\censupeg\resources\views//call/call.blade.php ENDPATH**/ ?>